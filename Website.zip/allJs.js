var content = 3
var footer = 2
var header = 1
